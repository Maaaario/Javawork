
public class OrderItem {
int b1,b2,b3,b1num,b2num,b3num;
public OrderItem(){}

    public OrderItem(int b1, int b1num, int b2, int b2num, int b3, int b3num) {
        this.b1=b1;
        this.b2=b2;
        this.b3=b3;
        this.b1num = b1num;
        this.b2num=b2num;
        this.b3num=b3num;

       
    
    }


 
 
  
   



  

}