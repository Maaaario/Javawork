public class Book {

    public Book() {

    }

    public String getname(int booknum) {

        if (booknum == 1) {

            Book1 b1 = new Book1();
            bookName = b1.bookName;

        } else if (booknum == 2) {
            Book1 b2 = new Book1();
            bookName = b2.bookName;
        } else if (booknum == 3) {
            Book1 b3 = new Book1();
            bookName = b3.bookName;
        }
        return bookName;
    }
    public double getprice(int bookprice) {

        if (bookprice == 1) {

            Book1 b1 = new Book1();
            price = b1.price;

        } else if (bookprice == 2) {
            Book1 b2 = new Book1();
            price = b2.price;
        } else if (bookprice == 3) {
            Book1 b3 = new Book1();
            price = b3.price;
        }
        return price;
    }

    int bookId = 00000;
    String bookName;
    double price;
    int storage;

    public class Book1 {
        int bookId = 1;
        String bookName = "Java指南";
        double price = 232.4;
        int storage = 999;
    }

    public class Book2 {
        int bookId = 2;
        String bookName = "Python指南";
        double price = 99.9;
        int storage = 8;
    }

    public class Book3 {
        int bookId = 2;
        String bookName = "Php指南";
        double price = 121.3;
        int storage = 80;
    }
    Book1 book1 = new Book1();
    Book2 book2 = new Book2();
    Book3 book3 = new Book3();

public void printbook(){
       
    System.out.println("           图书列表"+"\n"+
    "图书编号    图书名称      图书单价    库存数量 "+"\n"+
    "----------------------------------------------"+"\n"+
book1.bookId+"           "+ book1.bookName+"       "+book1.price+"       "+book1.storage+"\n"+
book2.bookId+"           "+ book2.bookName+"      "+book2.price+"         "+book2.storage+"\n"+
book3.bookId+"           "+ book3.bookName+"        "+book3.price+"         "+book3.storage);



}
}