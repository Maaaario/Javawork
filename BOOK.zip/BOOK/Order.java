import java.text.SimpleDateFormat;
import java.util.Date;
public class Order {
    int b1,b2,b3,b1num,b2num,b3num;
    double price1;
    double price2;
    double price3;
    public Order(int b1, int b1num, int b2, int b2num, int b3, int b3num) {

        this.orderId++;
        this.b1=b1;
        this.b2=b2;
        this.b3=b3;
        this.b1num = b1num;
        this.b2num=b2num;
        this.b3num=b3num;
        Book book = new Book();
     this.price1 = book.getprice(b1);
     this.price2 = book.getprice(b2);
     this.price3 = book.getprice(b3);

     this.bookname1 = book.getname(b1);

     this.bookname2 = book.getname(b2);
     
      this.bookname3 = book.getname(b3);

    }
    String bookname1;
    String bookname2;
    String bookname3;
OrderItem orderitem = new OrderItem(b1,b2,b3,b1num,b2num,b3num);
    int orderId = 100000;
    

    public double total() {


        return  
        this.b1num*this.price1+this.b2num*this.price2+this.b3num*this.price3;
      }
   
    
public void items(){
    Date t = new Date();
        

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
    

  Book newbook = new Book();

    System.out.println("           图书订单"+"\n"+"图书订单号："+orderId+"\n"+
                       "图书名称    购买数量      图书单价    "+"\n"+
                       "----------------------------------------------"+"\n"+
         bookname1+"     "+b1num+"            "+newbook.book1.price+"\n"+
         bookname2+"     "+b2num+"              "+newbook.book2.price+"\n"+
         bookname3+"     "+b3num+"               "+newbook.book3.price+"\n"+
        "----------------------------------------------"+"\n"+
        "订单总额：                        "+ total()  +
       "\n"+ "日期:             "+
       sdf.format(t)
        );
}



  

}