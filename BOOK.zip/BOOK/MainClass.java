
import java.util.*;
import java.util.Scanner;

public class MainClass {

    public static void main(String[] args) {
        Book book = new Book();
     book.printbook();



        System.out.println("请输入图书编号选择图书：");
        Scanner sc1 = new Scanner(System.in);
        int b1 = sc1.nextInt();
       
        System.out.println("请输入购买图书数量：");
        int b1num = sc1.nextInt();
        System.out.println("请继续购买图书。");

        System.out.println("请输入图书编号选择图书：");
        Scanner sc2 = new Scanner(System.in);
        int b2 = sc2.nextInt();
        System.out.println("请输入购买图书数量：");
        int b2num = sc2.nextInt();
        System.out.println("请继续购买图书。");

        System.out.println("请输入图书编号选择图书：");
        Scanner sc3 = new Scanner(System.in);
        int b3 = sc3.nextInt();
        System.out.println("请输入购买图书数量：");
        int b3num = sc3.nextInt();
   

        Order order = new Order(b1, b1num, b2, b2num, b3, b3num);
        OrderItem orderItem = new OrderItem(b1, b1num, b2, b2num, b3, b3num);
       
        order.items();
    }
    }
